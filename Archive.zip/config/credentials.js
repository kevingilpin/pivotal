module.exports = {
    cookieSecret: '5S3nw!kP',
    mongo: {
        development: {
            connectionString: 'mongodb://kevin:Bacon1211@ds013495.mlab.com:13495/pivotal_insights_demo'
        },
        production: {
            connectionString: 'mongodb://kevin:Bacon1211@ds013495.mlab.com:13495/pivotal_insights_demo'
        }
    }
};