module.exports = function(grunt) {

  grunt.initConfig({
    mochaTest: {
        test: {
            src: 'qa/tests-*.js',
            options: { ui: 'tdd' }
        }
    },
    jshint: {
      app: ['app.js', 'public/js/**/*.js', 'lib/**/*.js'],
      qa: ['Gruntfile.js', 'public/qa/**/*.js', 'qa/**/*.js'],
      options: {
        globals: {
          jQuery: true
        }
      }
    },
    exec: {
        linkchecker: {
            cmd: 'linkcheck http://localhost:3000/',
        }
    },
    watch: {
      files: ['<%= jshint.app %>', '<%= jshint.qa %>'],
      tasks: ['jshint']
    }
  });

  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-mocha-test');
  grunt.loadNpmTasks('grunt-exec');

  grunt.registerTask('default', ['mochaTest', 'jshint', 'exec']);

};
